package me.MitchellTaylor.Main;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class ImageCanvas extends Canvas {
	
	public String fileName;
	
	// Initialiser
	public ImageCanvas(String fileName) {
		this.fileName = fileName;
	}
	
	public void paint(Graphics g) {
		
		 Toolkit toolkit = Toolkit.getDefaultToolkit();
		 Image image = toolkit.getImage(fileName);
		 
		 g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), this);
	
	}
	
	public static void main(String[] args) {
		
		ImageCanvas imageCanvas = new ImageCanvas(null);
		JFrame frame = new JFrame();
		frame.add(imageCanvas);
		frame.setSize(400, 400);
		frame.setVisible(true);
	}

}
