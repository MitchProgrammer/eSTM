//
// --------------------------
// eSports Tournament Manager
// --------------------------
//
// Programmed by: Mitchell Taylor
//
//
// Programmed in Java 17
// Version 1.1.7
//


// Package referencing
package me.MitchellTaylor.Main;


// Importing libraries
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Label;
import java.awt.List;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import java.util.Arrays;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.TransferHandler;

import javax.swing.filechooser.FileSystemView;



@SuppressWarnings("serial")
public class Main extends Frame {
	
	// Defining variables
	static String entryBoxValue;
	static String fileWriter;
	static String filePath;
	static String write;
	static String selectedFilePath;
	static String listSelectedItem;
	static String listManipSelectedIndex;
	
	static Integer listSelectedIndex;
	static Integer entryBoxValueLength;
	static Integer participantListLength;

	static String[] participantList;
	
	static JFileChooser importedFile;
	
	
	// Main method
	public Main() {
		
		// Main Title 
		Label mainTitle = new Label("eSports Tournament Manager");
		mainTitle.setBounds(0, 25, 1000, 50);
		mainTitle.setAlignment(Label.CENTER);
		mainTitle.setFont(new Font("Arial", Font.PLAIN, 42));
		add(mainTitle);
		
		// Participant Data Field Label
		Label participantDataFieldLabel = new Label("Participant Data");
		participantDataFieldLabel.setBounds(625, 120, 300, 30);
		participantDataFieldLabel.setAlignment(Label.CENTER);
		participantDataFieldLabel.setFont(new Font("Arial", Font.PLAIN, 22));
		add(participantDataFieldLabel);
		
		// Fixture Table Label
		Label fixtureTableLabel = new Label("Fixture Table");
		fixtureTableLabel.setBounds(145, 120, 300, 30);
		fixtureTableLabel.setAlignment(Label.CENTER);
		fixtureTableLabel.setFont(new Font("Arial", Font.PLAIN, 22));
		add(fixtureTableLabel);
		
		
		// Exported data label
		Label exportedDataLabel = new Label("Filename:");
		exportedDataLabel.setBounds(625, 560, 100, 30);
		exportedDataLabel.setFont(new Font("Arial", Font.PLAIN, 16));
		add(exportedDataLabel);
		
		
		// Participant Data Field
		List participantDataField = new List(5);
		participantDataField.setBounds(625, 150, 300, 250);
		add(participantDataField);
		
		
		// EntryBox, used to add records to participantDataArray 
		TextField entryBox = new TextField();
		entryBox.setBounds(625, 400, 180, 40);
		add(entryBox);
		
		
		// EntryBox, used to name the exported file
		TextField exportedFileEntryBox = new TextField();
		exportedFileEntryBox.setBounds(725, 560, 200, 30);
		add(exportedFileEntryBox);
		
		// Finalists
		Label finalistsLabel = new Label("Finalists:");
		finalistsLabel.setFont(new Font("Arial", Font.PLAIN, 22));
		finalistsLabel.setBounds(50, 475, 300, 40);
		add(finalistsLabel);
		
		
		// Drag and Drop TextFields
		
		// TextField1
		JTextField fixtureTextField1 = new JTextField("Finalist 1");
		fixtureTextField1.setTransferHandler(new TransferHandler("text"));
		fixtureTextField1.setBounds(50, 515, 125, 40);
		
		// Mouse listener
		MouseListener listener1 = new MouseAdapter() {
		      public void mousePressed(MouseEvent me) {
		        JComponent comp = (JComponent) me.getSource();
		        TransferHandler handler = comp.getTransferHandler();
		        handler.exportAsDrag(comp, me, TransferHandler.COPY);
		      }
		    };
		    
		// Adds listener
		fixtureTextField1.addMouseListener(listener1);
		
		add(fixtureTextField1);
		
		// TextField2
		JTextField fixtureTextField2 = new JTextField("Finalist 2");
		fixtureTextField2.setTransferHandler(new TransferHandler("text"));
		fixtureTextField2.setBounds(175, 515, 125, 40);
				
		// Mouse listener
		MouseListener listener2 = new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				JComponent comp = (JComponent) me.getSource();
				TransferHandler handler = comp.getTransferHandler();
				handler.exportAsDrag(comp, me, TransferHandler.COPY);
			}
		};
				    
		// Adds listener
		fixtureTextField2.addMouseListener(listener2);
				
		add(fixtureTextField2);
		
		// TextField3
		JTextField fixtureTextField3 = new JTextField("Finalist 3");
		fixtureTextField3.setTransferHandler(new TransferHandler("text"));
		fixtureTextField3.setBounds(300, 515, 125, 40);
				
		// Mouse listener
		MouseListener listener3 = new MouseAdapter() {
		      public void mousePressed(MouseEvent me) {
		    	  JComponent comp = (JComponent) me.getSource();
		    	  TransferHandler handler = comp.getTransferHandler();
		    	  handler.exportAsDrag(comp, me, TransferHandler.COPY);
		      }
		    };
				    
		// Adds listener
		fixtureTextField3.addMouseListener(listener3);
				
		add(fixtureTextField3);
		
		// TextField4
		JTextField fixtureTextField4 = new JTextField("Finalist 4");
		fixtureTextField4.setTransferHandler(new TransferHandler("text"));
		fixtureTextField4.setBounds(425, 515, 125, 40);
				
		// Mouse listener
		MouseListener listener4 = new MouseAdapter() {
		    public void mousePressed(MouseEvent me) {
		        JComponent comp = (JComponent) me.getSource();
		        TransferHandler handler = comp.getTransferHandler();
		        handler.exportAsDrag(comp, me, TransferHandler.COPY);
		      }
		    };
				    
		// Adds listener
		fixtureTextField4.addMouseListener(listener4);
				
		add(fixtureTextField4);


		// TextField5
		JTextField fixtureTextField5 = new JTextField("Finalist 5");
		fixtureTextField5.setTransferHandler(new TransferHandler("text"));
		fixtureTextField5.setBounds(50, 555, 125, 40);
				
		// Mouse listener
		MouseListener listener5 = new MouseAdapter() {
		      public void mousePressed(MouseEvent me) {
		        JComponent comp = (JComponent) me.getSource();
		        TransferHandler handler = comp.getTransferHandler();
		        handler.exportAsDrag(comp, me, TransferHandler.COPY);
		      }
		    };
				    
		// Adds listener
		fixtureTextField5.addMouseListener(listener5);
				
		add(fixtureTextField5);
				
		// TextField6
		JTextField fixtureTextField6 = new JTextField("Finalist 6");
		fixtureTextField6.setTransferHandler(new TransferHandler("text"));
		fixtureTextField6.setBounds(175, 555, 125, 40);
						
		// Mouse listener
		MouseListener listener6 = new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				JComponent comp = (JComponent) me.getSource();
				TransferHandler handler = comp.getTransferHandler();
				handler.exportAsDrag(comp, me, TransferHandler.COPY);
			}
		};
						    
		// Adds listener
		fixtureTextField6.addMouseListener(listener6);
						
		add(fixtureTextField6);
				
		// TextField7
		JTextField fixtureTextField7 = new JTextField("Finalist 7");
		fixtureTextField7.setTransferHandler(new TransferHandler("text"));
		fixtureTextField7.setBounds(300, 555, 125, 40);
						
		// Mouse listener
		MouseListener listener7 = new MouseAdapter() {
		      public void mousePressed(MouseEvent me) {
			   	  JComponent comp = (JComponent) me.getSource();
		    	  TransferHandler handler = comp.getTransferHandler();
		    	  handler.exportAsDrag(comp, me, TransferHandler.COPY);
		      }
		    };
						    
		// Adds listener
		fixtureTextField7.addMouseListener(listener7);
						
		add(fixtureTextField7);
				
		// TextField8
		JTextField fixtureTextField8 = new JTextField("Finalist 8");
		fixtureTextField8.setTransferHandler(new TransferHandler("text"));
		fixtureTextField8.setBounds(425, 555, 125, 40);
						
		// Mouse listener
		MouseListener listener8 = new MouseAdapter() {
		    public void mousePressed(MouseEvent me) {
		        JComponent comp = (JComponent) me.getSource();
		        TransferHandler handler = comp.getTransferHandler();
		        handler.exportAsDrag(comp, me, TransferHandler.COPY);
		      }
		    };
				    
		// Adds listener
		fixtureTextField8.addMouseListener(listener8);
						
		add(fixtureTextField8);

		
		
		// Fixture Buttons
		
		// Finals
		JButton fixtureButton1 = new JButton("Finalist");
		fixtureButton1.setBounds(50, 400, 120, 30);
		fixtureButton1.setTransferHandler(new TransferHandler("text"));
		fixtureButton1.setFocusable(false);
		add(fixtureButton1);

		JButton fixtureButton2 = new JButton("Finalist");
		fixtureButton2.setBounds(50, 430, 120, 30);
		fixtureButton2.setTransferHandler(new TransferHandler("text"));
		fixtureButton2.setFocusable(false);
		add(fixtureButton2);

		JButton fixtureButton3 = new JButton("Finalist");
		fixtureButton3.setBounds(175, 400, 120, 30);
		fixtureButton3.setTransferHandler(new TransferHandler("text"));
		fixtureButton3.setFocusable(false);
		add(fixtureButton3);
		
		JButton fixtureButton4 = new JButton("Finalist");
		fixtureButton4.setBounds(175, 430, 120, 30);
		fixtureButton4.setTransferHandler(new TransferHandler("text"));
		fixtureButton4.setFocusable(false);
		add(fixtureButton4);
		
		JButton fixtureButton5 = new JButton("Finalist");
		fixtureButton5.setBounds(300, 400, 120, 30);
		fixtureButton5.setTransferHandler(new TransferHandler("text"));
		fixtureButton5.setFocusable(false);
		add(fixtureButton5);
		
		JButton fixtureButton6 = new JButton("Finalist");
		fixtureButton6.setBounds(300, 430, 120, 30);
		fixtureButton6.setTransferHandler(new TransferHandler("text"));
		fixtureButton6.setFocusable(false);
		add(fixtureButton6);
		
		JButton fixtureButton7 = new JButton("Finalist");
		fixtureButton7.setBounds(425, 400, 120, 30);
		fixtureButton7.setTransferHandler(new TransferHandler("text"));
		fixtureButton7.setFocusable(false);
		add(fixtureButton7);
		
		JButton fixtureButton8 = new JButton("Finalist");
		fixtureButton8.setBounds(425, 430, 120, 30);
		fixtureButton8.setTransferHandler(new TransferHandler("text"));
		fixtureButton8.setFocusable(false);
		add(fixtureButton8);
		
		// Semi Finals
		JButton fixtureButton9 = new JButton("Semi-Finalist");
		fixtureButton9.setBounds(110, 320, 120, 30);
		fixtureButton9.setTransferHandler(new TransferHandler("text"));
		fixtureButton9.setFocusable(false);
		add(fixtureButton9);
		
		JButton fixtureButton10 = new JButton("Semi-Finalist");
		fixtureButton10.setBounds(110, 350, 120, 30);
		fixtureButton10.setTransferHandler(new TransferHandler("text"));
		fixtureButton10.setFocusable(false);
		add(fixtureButton10);
		
		JButton fixtureButton11 = new JButton("Semi-Finalist");
		fixtureButton11.setBounds(360, 320, 120, 30);
		fixtureButton11.setTransferHandler(new TransferHandler("text"));
		fixtureButton11.setFocusable(false);
		add(fixtureButton11);
		
		JButton fixtureButton12 = new JButton("Semi-Finalist");
		fixtureButton12.setBounds(360, 350, 120, 30);
		fixtureButton12.setTransferHandler(new TransferHandler("text"));
		fixtureButton12.setFocusable(false);
		add(fixtureButton12);
		
		// Grand Final
		JButton fixtureButton13 = new JButton("Grand Finalist");
		fixtureButton13.setBounds(235, 260, 120, 30);
		fixtureButton13.setTransferHandler(new TransferHandler("text"));
		fixtureButton13.setFocusable(false);
		add(fixtureButton13);
		
		JButton fixtureButton14 = new JButton("Grand Finalist");
		fixtureButton14.setBounds(235, 290, 120, 30);
		fixtureButton14.setTransferHandler(new TransferHandler("text"));
		fixtureButton14.setFocusable(false);
		add(fixtureButton14);
		
		// Winner
		JButton fixtureButton15 = new JButton("Champion");
		fixtureButton15.setBounds(235, 180, 120, 30);
		fixtureButton15.setTransferHandler(new TransferHandler("text"));
		fixtureButton15.setFocusable(false);
		add(fixtureButton15);
		
		
		// Add item button
		Button addItemButton = new Button("Add");
		addItemButton.setBounds(805, 400, 60, 40);
				
		// Runs when button is clicked
		addItemButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				try {
					entryBoxValue = entryBox.getText();
					entryBoxValueLength = entryBoxValue.length();
					if(entryBoxValueLength >= 1) {
						participantDataField.add(entryBoxValue);
					}
					else {
						JOptionPane.showMessageDialog(null, "Please enter a valid value", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
				}
				catch(Exception error) {
					JOptionPane.showMessageDialog(null, "Please enter a valid value", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
				
		add(addItemButton);
		
		// Edit item button
		Button editItemButton = new Button("Edit");
		editItemButton.setBounds(865, 400, 60, 40);
		
		// Runs when button clicked
		editItemButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				try {
					// Gets values
					listSelectedItem = participantDataField.getSelectedItem();
					listSelectedIndex = participantDataField.getSelectedIndex();
					
					// Updates entryBoxValue
					entryBoxValue = entryBox.getText();
					
					// Edits value
					participantDataField.remove(listSelectedItem);
					participantDataField.add(entryBoxValue, listSelectedIndex);
				}
				catch(Exception error) {
					JOptionPane.showMessageDialog(null, "No item selected to edit", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
			
		});
		
		add(editItemButton);
		
		
		// Remove item button
		Button removeItemButton = new Button("Remove");
		removeItemButton.setBounds(625, 440, 100, 40);
		
		// Runs when button is clicked
		removeItemButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				try {
					listSelectedItem = participantDataField.getSelectedItem();
					participantDataField.remove(listSelectedItem);
				}
				catch(Exception error) {
					JOptionPane.showMessageDialog(null, "Please select a valid value", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		add(removeItemButton);
		
		
		// Remove all items button
		Button removeAllItemsButton = new Button("Remove all");
		removeAllItemsButton.setBounds(725, 440, 100, 40);
		
		// Runs when button is clicked
		removeAllItemsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				try {
					participantDataField.removeAll();
				}
				catch(Exception error) {
					JOptionPane.showMessageDialog(null, "Could not remove items", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		add(removeAllItemsButton);
		
		
		// Order items button
		Button orderItemsButton = new Button("Order items");
		orderItemsButton.setBounds(825, 440, 100, 40);
		
		// Runs when button is clicked
		orderItemsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				try {
					
					// Gets data in participantDataField
					participantList = participantDataField.getItems();
					
					// Sorts the data in Alphabetical order
					Arrays.sort(participantList);
					
					// Removes the data to insert new ordered data
					participantDataField.removeAll();
					
					// Inserts new sorted data into participantDataField
					for(int i = 0; i <participantList.length; i++) {
						participantDataField.add(participantList[i]);
					}
				}
				catch(Exception error) {
					JOptionPane.showMessageDialog(null, "Unknown error occured", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		
		add(orderItemsButton);
		
		
		// Import file button
		Button importFileButton = new Button("Import File");
		importFileButton.setBounds(625, 480, 150, 40);
		
		importFileButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Sets home directory
				importedFile = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
				int returnValue = importedFile.showOpenDialog(null);
				
				// Finds file directory path and assigns selectedFilePath to it
				if(returnValue == JFileChooser.APPROVE_OPTION) {
					File selectedFile = importedFile.getSelectedFile();
					selectedFilePath = (selectedFile.getAbsolutePath());
				}
				
				// Opens the selected file
				File selectedFile = new File(selectedFilePath);
				try {
					try (Scanner fileRead = new Scanner(selectedFile)) {
						// Deletes previous data
						participantDataField.removeAll();
						// Adds data from file to participantDataInfo
						while(fileRead.hasNextLine()) {
							String fileLine = fileRead.nextLine();
							participantDataField.add(fileLine);
						}
					}
					
				} catch (FileNotFoundException error) {
					error.printStackTrace();
				}
			}
		});
		
		add(importFileButton);
		
		
		// Export file button
		Button exportFileButton = new Button("Export File");
		exportFileButton.setBounds(775, 480, 150, 40);
		
		exportFileButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				// Creates text file
				try {
					File exportedFile = new File(exportedFileEntryBox.getText() + ".txt");
					if(exportedFile.createNewFile()) {
						JOptionPane.showMessageDialog(null, "Data exported successfully as " + exportedFileEntryBox.getText() + ".txt", "Info", JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						JOptionPane.showMessageDialog(null, "Filename already exists", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				catch(IOException error) {
					JOptionPane.showMessageDialog(null, "Unknown error occured", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
				// Opens text file
				try {
					filePath = (exportedFileEntryBox.getText() + ".txt");
					File f = new File(filePath);
					
					if (f.createNewFile()) {
						System.out.println("Successfully created file");
					}
				}
				catch(IOException error) {
					JOptionPane.showMessageDialog(null, "Unknown error occured", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
				// Writes to text file
				try {
					FileWriter write = new FileWriter(filePath);
					participantListLength = participantDataField.getItemCount();
					for(int i = 0; i < participantListLength; i++) {
						write.write(participantDataField.getItem(i) + "\n");
					}
					write.close();
				}
				catch (IOException error) {
					System.out.println(error.getMessage());
				}
			}
		});
		
		add(exportFileButton);
		
		// Manipulate data Button
		Button manipulateButton = new Button("Manipulate Data");
		manipulateButton.setBounds(625, 520, 300, 40);
		manipulateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				try {
					listManipSelectedIndex = participantDataField.getItem(0);
					fixtureTextField1.setText(listManipSelectedIndex);
					fixtureButton1.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(1);
					fixtureTextField2.setText(listManipSelectedIndex);
					fixtureButton3.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(2);
					fixtureTextField3.setText(listManipSelectedIndex);
					fixtureButton5.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(3);
					fixtureTextField4.setText(listManipSelectedIndex);
					fixtureButton7.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(4);
					fixtureTextField5.setText(listManipSelectedIndex);
					fixtureButton2.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(5);
					fixtureTextField6.setText(listManipSelectedIndex);
					fixtureButton4.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(6);
					fixtureTextField7.setText(listManipSelectedIndex);
					fixtureButton6.setText(listManipSelectedIndex);
					
					listManipSelectedIndex = participantDataField.getItem(7);
					fixtureTextField8.setText(listManipSelectedIndex);
					fixtureButton8.setText(listManipSelectedIndex);
				}
					
				catch(Exception error) {
					JOptionPane.showMessageDialog(null, "Not enough fields to manipulate data correctly", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}

		});
		
		add(manipulateButton);
		
		
		// Canvas
		ImageCanvas imageCanvas = new ImageCanvas("Tournament-Fixture-Table-32px48px.png");
		add(imageCanvas);
		imageCanvas.setSize(480, 320);
		imageCanvas.setBounds(50, 150, 500, 320);
		imageCanvas.setBackground(Color.WHITE);
		imageCanvas.setVisible(true);
		
		// Image Icon
		Image icon = Toolkit.getDefaultToolkit().getImage("Icon-16px16px.png");
		setIconImage(icon);
		
		
		
		// Frame configuration
		setSize(1000, 610);
		setTitle("eSports Tournament Manager");
		setLayout(null);
		setVisible(true);
		
		
		
		
		// Adds window listener to allow application to be closed
		addWindowListener (new WindowAdapter() {    
			public void windowClosing (WindowEvent event) {    
				dispose();    
			}    
		});
		
		
	}
	
	
	// Calls Main() method to open application
	public static void main(String[] args) {
		new Main();
		
	}
}
